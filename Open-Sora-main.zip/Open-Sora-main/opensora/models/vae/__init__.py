from .autoencoder_2d import AutoEncoderFlux
from .discriminator import N_LAYER_DISCRIMINATOR_3D
