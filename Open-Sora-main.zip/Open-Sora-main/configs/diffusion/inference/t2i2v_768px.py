_base_ = [  # inherit grammer from mmengine
    "768px.py",
    "plugins/t2i2v.py",
]
