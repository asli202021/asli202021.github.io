_base_ = [  # inherit grammer from mmengine
    "256px.py",
    "plugins/tp.py",  # use tensor parallel
]
