_base_ = [  # inherit grammer from mmengine
    "256px.py",
    "plugins/t2i2v.py",
]
